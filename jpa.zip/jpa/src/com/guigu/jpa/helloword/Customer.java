package com.guigu.jpa.helloword;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@NamedQuery(name="testNamedQuery",query="from Customer c where c.id =?")
@Cacheable(true)
@Table(name="jpa_customer")
@Entity
public class Customer {

	private Integer id;
	private String lastName;
	private String email;
	private int ege;
	private Date createTime;
	private Date birth;
	
	
	
	public Customer() {
		super();
	}
	
	

	public Customer(String lastName,  int ege) {
		this.lastName = lastName;
		this.ege = ege;
	}



	private Set<Order> orders=new HashSet<>();
	
	//ӳ�䵥�� 1-n �Ĺ�����ϵ
	//ʹ�� @OneToMany ��ӳ�� 1-n �Ĺ�����ϵ
	//ʹ��mappedBy��ȡ��1�˵�ӳ���ϵ����������sql��䣨ps��mappedBy��ֵΪn�˵�����Customer������Ա�������
	//ע��: ���� 1 ��һ��  (�˴���1�ˣ�ĸ����)  �� @OneToMany ��ʹ�� mappedBy ����, �� @OneToMany �˾Ͳ�����ʹ�� @JoinColumn ������. 
	@OneToMany(fetch = FetchType.LAZY,cascade= {CascadeType.REMOVE},mappedBy="customer")
	public Set<Order> getOrders() {
		return orders;
	}
	public void setOrders(Set<Order> orders) {
		this.orders = orders;
	}
	
	@GeneratedValue
	@Id
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getEge() {
		return ege;
	}
	public void setEge(int ege) {
		this.ege = ege;
	}
	
	@Transient
	public String getNameAndEge() {
		return "������"+this.lastName+"�����䣺"+String.valueOf(this.ege);
	}

	@Temporal(TemporalType.TIMESTAMP)
	public Date getCreateTime() {
		return createTime;
	}
	
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	@Temporal(TemporalType.DATE)
	public Date getBirth() {
		return birth;
	}
	
	public void setBirth(Date birth) {
		this.birth = birth;
	}
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", lastName=" + lastName + ", email=" + email + ", ege=" + ege + ", createTime="
				+ createTime + ", birth=" + birth + "]";
	}
	
}
