package com.guigu.jpa.helloword;

import java.util.Currency;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {
	
	public static void main(String[] args) {
		
		
		//===1.����EntityManagerFactory
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("jpa");
		
		
		//2.����EntityManager
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		//3.��������
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		
		//4.���г־û�����
		Customer customer = new Customer();
		customer.setEge(12);
		customer.setEmail("@qq508.com");
		customer.setLastName("Tian");
		customer.setBirth(new Date());
		customer.setCreateTime(new Date());
		
		entityManager.persist(customer);
		
		//5.�ύ����
		transaction.commit();
		
		//6.�ر�entityManager
		entityManager.close();
		
		//7.�ر�entityManagerFactory
		entityManagerFactory.close();
		
	}

}
